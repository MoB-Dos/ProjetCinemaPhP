package snippet;

public class Snippet {
	public static void main(String[] args) {
		 java.lang.ClassNotFoundException: com.mysql.jdbc.Driver
	}
}

