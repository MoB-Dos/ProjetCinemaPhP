package cantine2;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;

public class Connexionadmin {

	protected Shell shell;
	private Label lblLogin;
	private Label lblMotDePasse;
	private Text text;
	private Text text_1;
	private Label lblConnexionAdministrateur;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Connexionadmin window = new Connexionadmin();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
		shell.setSize(748, 587);
		shell.setText("SWT Application");
		
		Button btnConfirmation = new Button(shell, SWT.NONE);
		btnConfirmation.setBounds(301, 405, 105, 35);
		btnConfirmation.setText("confirmation");
		
		lblLogin = new Label(shell, SWT.NONE);
		lblLogin.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
		lblLogin.setBounds(325, 75, 81, 25);
		lblLogin.setText("Login : ");
		
		lblMotDePasse = new Label(shell, SWT.NONE);
		lblMotDePasse.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
		lblMotDePasse.setBounds(287, 239, 127, 25);
		lblMotDePasse.setText("Mot de passe : ");
		text = new Text(shell, SWT.BORDER);
		text.setBounds(165, 151, 366, 31);
		  String login = text.getText();

		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(165, 285, 366, 31);
		  String mdp = text_1.getText();

		lblConnexionAdministrateur = new Label(shell, SWT.NONE);
		lblConnexionAdministrateur.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
		lblConnexionAdministrateur.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblConnexionAdministrateur.setBounds(246, 10, 212, 25);
		lblConnexionAdministrateur.setText("Connexion Administrateur");

		System.out.println("ezeza"+text.getText());
		
		

	}
}
