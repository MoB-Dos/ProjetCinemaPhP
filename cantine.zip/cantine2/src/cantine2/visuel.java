package cantine2;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.wb.swt.SWTResourceManager;

public class visuel {

	protected Shell shell;
	private Table table;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			visuel window = new visuel();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @throws SQLException 
	 */
	public void open() throws SQLException {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @param nom 
	 * @throws SQLException 
	 */
	protected void createContents(Object nom) throws SQLException {
		shell = new Shell();
		shell.setSize(754, 557);
		shell.setText("SWT Application");
		
		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION);
		table.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		table.setToolTipText("a");
		table.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
		table.setBounds(10, 22, 698, 357);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tblclmnId = new TableColumn(table, SWT.NONE);
		tblclmnId.setWidth(100);
		tblclmnId.setText("id");
		
		TableColumn tblclmnNom = new TableColumn(table, SWT.NONE);
		tblclmnNom.setWidth(100);
		tblclmnNom.setText("Nom");
		
		TableColumn tblclmnPrenom = new TableColumn(table, SWT.NONE);
		tblclmnPrenom.setWidth(100);
		tblclmnPrenom.setText("Prenom");
		
		TableColumn tblclmnRgime = new TableColumn(table, SWT.NONE);
		tblclmnRgime.setWidth(100);
		tblclmnRgime.setText("R\u00E9gime");
		
		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(100);
		tblclmnNewColumn.setText("Profil");
		
		TableColumn tblclmnNewColumn_1 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_1.setWidth(116);
		tblclmnNewColumn_1.setText("Prix par mois");
		
		String url="jdbc:mysql://localhost/projetjava2?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
			String user="root";
			String password="";
       try {
		Class.forName("com.mysql.jdbc.Driver").newInstance();
	} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
       Connection con = DriverManager.getConnection(url, user, password);
       Statement stmt = con.createStatement();
       ResultSet result = stmt.executeQuery("SELECT * FROM user");
       //On r�cup�re les MetaData
       java.sql.ResultSetMetaData resultMeta = result.getMetaData();
		
       for(int i = 1; i <= resultMeta.getColumnCount(); i++)
       {
    	  String nom = result.getString("nom");
           String prenom= result.getString("prenom");
           String regime = result.getString("regime");
           String profil = result.getString("profil");
           Object[] obj = new Object[5];
           obj[0] = nom;
           obj[1] = prenom;
           obj[2] = regime;
           obj[3] = profil;
           objs.add(obj);
    	   TableItem ligne1 = new TableItem(table,SWT.NONE);
   		ligne1.setText(new String[] {nom, prenom, regime, profil,"en cours","en cours",});
       }
		
	}
	
}
