package cantine2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
public class connexion {
	



		public static void main(String[] args) {
		       try{
		   			String url="jdbc:mysql://localhost/projetjava2?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
		   			String user="root";
		   			String password="";
		           Class.forName("com.mysql.jdbc.Driver").newInstance();
		           Connection con = DriverManager.getConnection(url, user, password);
		           Statement stmt = con.createStatement();
		           ResultSet result = stmt.executeQuery("SELECT * FROM user");
		           if(request.getParameter(result) != null){
		           //On r�cup�re les MetaData
		            System.out.println("Connexion r�ussi admin !");
		           }
		           else {
			            System.out.println("Connexion �chou� moldu");

		           }
		           stmt.close();
		           con.close();
		        } catch(Exception e){
		            System.out.println("Connexion impossible: "+e);
		            System.exit(-1);  
		        }
		    }
	}

