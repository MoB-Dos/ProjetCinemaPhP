package cantine2;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JOptionPane;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.wb.swt.SWTResourceManager;

public class inscription {

	protected Shell shell;
	private Text text;
	private Text text_1;
	private Text text_2;
	private Text text_3;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			inscription window = new inscription();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	public void open() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	protected void createContents() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		shell = new Shell();
		shell.setSize(796, 723);
		shell.setText("SWT Application");
		
		Label lblInscription = new Label(shell, SWT.NONE);
		lblInscription.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblInscription.setBounds(294, 10, 81, 25);
		lblInscription.setText("Inscription");
		
		Label lblNom = new Label(shell, SWT.NONE);
		lblNom.setBounds(306, 71, 81, 25);
		lblNom.setText("Nom : ");
		
		text = new Text(shell, SWT.BORDER);
		text.setBounds(219, 120, 266, 31);
		String nom= text.getText();
		Label lblPrnom = new Label(shell, SWT.NONE);
		lblPrnom.setBounds(306, 184, 81, 25);
		lblPrnom.setText("Pr\u00E9nom : ");
		
		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(219, 233, 266, 31);
		String prenom= text_1.getText();
		Label lblRgime = new Label(shell, SWT.NONE);
		lblRgime.setBounds(306, 293, 81, 25);
		lblRgime.setText("R\u00E9gime : ");
		
		text_2 = new Text(shell, SWT.BORDER);
		text_2.setBounds(219, 340, 266, 31);
		String regime= text_2.getText();
		Label lblProfil = new Label(shell, SWT.NONE);
		lblProfil.setBounds(306, 399, 81, 25);
		lblProfil.setText("Profil : ");

		text_3 = new Text(shell, SWT.BORDER);
		text_3.setBounds(219, 442, 266, 31);
		
		Button btnInscrire = new Button(shell, SWT.NONE);
		btnInscrire.setBounds(294, 541, 105, 35);
		btnInscrire.setText("Inscrire");
		String profil= text_3.getText();


	

		String url="jdbc:mysql://localhost/projetjava2?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
		String user="root";
		String password="";
   Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
   Connection con = DriverManager.getConnection(url, user, password);
   Statement stmt = con.createStatement();
  
// create a sql date object so we can use it in our INSERT statement
   Calendar calendar = Calendar.getInstance();
   java.sql.Date startDate = new java.sql.Date(calendar.getTime().getTime());
	

btnInscrire.addListener(SWT.Selection, new Listener() {

	@Override
	public void handleEvent(Event arg0) {
		String query = " insert into user (nom, prenom, regime, profil)"
	             + " values (?, ?, ?, ?)";

	           // create the mysql insert preparedstatement
	           PreparedStatement preparedStmt = null;
			try {
				preparedStmt = con.prepareStatement(query);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	           try {
				preparedStmt.setString(1, text.getText());
				 preparedStmt.setString(2, text_1.getText());
		           preparedStmt.setString(3, text_2.getText());
		           preparedStmt.setString(4, text_3.getText());


		           // faudra faire l'affichage et l'onglet details avec les dates etc... (d�ja commencer en haut il reste plus qu'a mettre le jlabel et sql
		    
		           preparedStmt.execute();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	          
	      //Ex�cution de la requ�te 
	      JOptionPane.showMessageDialog(null, "Enregistrement effectu� avec succ�s");

		
	}
	
});
   
    
}                                        
	}

