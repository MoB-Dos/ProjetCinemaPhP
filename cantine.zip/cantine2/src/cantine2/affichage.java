package cantine2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class affichage {

	public static void main(String[] args) {
	       try{
	   			String url="jdbc:mysql://localhost/projetjava2?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	   			String user="root";
	   			String password="";
	           Class.forName("com.mysql.jdbc.Driver").newInstance();
	           Connection con = DriverManager.getConnection(url, user, password);
	           Statement stmt = con.createStatement();
	           ResultSet result = stmt.executeQuery("SELECT * FROM user");
	           //On r�cup�re les MetaData
	           java.sql.ResultSetMetaData resultMeta = result.getMetaData();
	              
	           System.out.println("\n**************************************************************************************************************************************************");
	           //On affiche le nom des colonnes
	           for(int i = 1; i <= resultMeta.getColumnCount(); i++)
	             System.out.print("\t" + resultMeta.getColumnName(i).toUpperCase() + "\t *");
	              
	           System.out.println("\n**************************************************************************************************************************************************");
	              
	           while(result.next()){         
	             for(int i = 1; i <= resultMeta.getColumnCount(); i++)
	               System.out.print("\t" + result.getObject(i).toString() + "\t |");
	                 
	             System.out.println("\n------------------------------------------------------------------------------------------------------------------------------------------------");

	           }
	           stmt.close();
	           con.close();
	        } catch(Exception e){
	            System.out.println("Connexion impossible: "+e);
	            System.exit(-1);  
	        }
	    }
}